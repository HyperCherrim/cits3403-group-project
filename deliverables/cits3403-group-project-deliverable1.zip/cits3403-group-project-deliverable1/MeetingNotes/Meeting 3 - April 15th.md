
## This week?:
- General goal for 22/04 - Setting up the server?

## Roadmap
- 4 weeks until Doomsday

This Week (wk7):
- "Bones" of the backend
Wk8:
- JawaScript (client-side) to make things work
	- Time/date things

Deliverable1: Just the HTML

Dev2: CSS?
Dev3: Final?

Callum - basic construction of the backend and conjuring it into existence
Nathan - sign-in and prototyping of date/time 
Myself (Atticus) - Restyle the index page and (also restyle the table to be more suited for smaller screens)
Krish - Fixing the `making_request` page

Index - Instead of a table, use circles w/ rounded-corner rectangles, w/ part of the description and unit name 
- However, this would not work on mobile - cut it down a bit on smaller screens?


## Java server/client datetime exchange
- List of tuples?


- Limitations on how many repeats are allowed?

- Date/time baseline: MS system?


## NOTE:
- Callum stated he like's Krish's shirt (3:56pm)

### But seriously:
- *adjourned* (3:57pm)