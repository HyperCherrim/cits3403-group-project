# cits3403-group-project

A description of the purpose of the application, explaining its design and use:

To create schedules of study groups and their meetings. Plan dates, tag your units and chat with your peers.

A table with each row containing the i) UWA ID ii) name and iii) Github user name of the group members:

| Student ID | Student Name     | GitHub Name     |
|------------|------------------|-----------------|
| 23724285   | Krish Dubey      | Krish-Dubey     |
| 23924286   | Atticus Bond     | HyperCherrim    |
| 23631345   | Callum Greenwald | CallumGreenwald |
| 23120741   | Nathan Foley     | Nathan-Foley    |

A brief summary of the architecture of the application.

~~Using html, css, etc.~~

instructions for how to launch the application.

~~Open the wesbite.html and run.~~ NYI

instructions for how to run the tests for the application.

Currently no tests due to being in the early stages of development.
