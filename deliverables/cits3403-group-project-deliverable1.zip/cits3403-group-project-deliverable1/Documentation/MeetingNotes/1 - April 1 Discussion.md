
## Last week:
- Goals achieved (creation of basic files) - thanks Nathan!

## Potential goals for this week:
- Make a mockup of the HTML/CSS
	- Effectively getting the layout sorted and "making it look like the website is functional" - 
		- Prototype
	- First deliverable?


- Creation of HTML code for making and responding to requests

- Delegation:
	- One person - HTML for making requests
	- Another - making HTML for responding to requests
	- Third - CSS for one of the pages
	- Fourth - CSS for the other page
## How?
### Styling:
- Green/white?
	- Homepage styling:
		- Green navbar
		- List of study groups listed in centre of page
		- Tags top-middle below the search bar
- Buttons:
	- Account operations

## Pages
- Minimum:
	- Make a request (request for study group, tags, title, description, times etc.)
	- See the requests (mockup in the Teams call)
		- Page for responding to request
		- Specification of time
	- Account creation
		- Account login
	- Along with the CSS

- Nathan: Account pages
- Callum: Making a request page
- Krish: Answering a request page
- Myself (Atticus): Home page (w/ mockup list of requests)
	- Placeholders
	- Maybe give them a class?

- Next time: Saturday?